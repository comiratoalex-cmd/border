# 🌈 Neon Overlay Generator — GitHub Pages Edition

Gerador avançado de bordas neon animadas para OBS e overlays.

## 🚀 Como publicar no GitHub Pages
- Suba todos os arquivos no repositório
- Vá em Settings → Pages
- Selecione Branch: main e Folder: /
- Aguarde o link ficar ativo

## 📦 Estrutura
- index.html
- style.css
- script.js
- /assets/logo.png
